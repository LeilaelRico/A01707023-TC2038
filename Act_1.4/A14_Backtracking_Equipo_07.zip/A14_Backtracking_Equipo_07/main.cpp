/***********************************************************
 *                      ITESM Querétaro                    *
 *                          TC2038                         *
 *          Análisis y Diseño de Algoritmos Avanzados      *
 *                       Actividad 1.4                     *
 *                        29/08/2022                       *
 *           Olivia Araceli Morales Quezada A10707371      *
 *           Cristian Leilael Rico Espinosa A01707023      *
 ***********************************************************/

/***********************************************************
 * Actividad 1.4 Implementación de la técnica de           *
 *  programación "backtracking" y "ramificación y poda"    *            
 ***********************************************************/


#include <iostream>
#include <vector>

using namespace std;

vector<vector<int> > maze, solRatInMaze;
int N, M;

/************************************************************
*  Su complejidad es de O(3^(M x N)).                      *
*  Simula un laberinto que debe de ser atravesado.         *
*  Imprime una matriz de valores booleanos que             *
*   representan el camino para salir del laberinto.        *
************************************************************/

/************************************************************
*  Imprime las matrices del laberinto                      *
************************************************************/

void print(vector<vector<int> > vec)
{
    for (int i = 0; i < vec.size(); i++)
    {
        for (int j = 0; j < vec[i].size(); j++)
        {
            cout << vec[i][j] << " ";
        }
        cout << endl;
    }
}

bool isAccessible(int x, int y)
{

    if (x < N && x >= 0 && y < M && y >= 0 && maze[x][y] == 1)
        return true;
    else
        return false;
}

/************************************************************
*  Función auxiliar que comrueba el camino a elegir;       *
*  Como el movimiento está limitado a moverse hacia abajo  *
*  o a la izquierda, el programa determina cuál de estas   *
*  dos opciones es la mejor a seguir (recordando que       *
*  solamente puede avanzar en los "1" de la matriz)        *
************************************************************/

bool auxBackTrack(vector<vector<int> >& auxSol, int x, int y)
{
    if (x == N - 1 && y == M - 1 && maze[x][y] == 1)
    {
        auxSol[x][y] = 1;
        return true;
    }

    if (isAccessible(x, y))
    {
        if (auxSol[x][y] == 1)
        {
            return false;
        }

        auxSol[x][y] = 1;

        if (auxBackTrack(auxSol, x + 1, y) == true)
            return true;

        if (auxBackTrack(auxSol, x, y + 1) == true)
            return true;

        if (auxBackTrack(auxSol, x, y - 1) == true)
            return true;

        if (auxBackTrack(auxSol, x - 1, y) == true)
            return true;

        auxSol[x][y] = 0;
        return false;
    }
    return false;
}

/************************************************************
*  Función recursiva principal la cual estará llamando     *
*  a la función auxiliar hasta terminar de recorrer el     *
*  arreglo. Una vez finalizado, imprime en pantalla        *
*  la ruta hacia la salida o, en caso de que este no tenga *
*  solución, desplegrará un mensaje.                       *
************************************************************/

void backTracking()
{
    if (auxBackTrack(solRatInMaze, 0, 0) == true)
    {
        cout << "\nSolucion: " << endl;
        print(solRatInMaze);
    }
    else
        cout << "No se ha encontrado una solucion" << endl;
}

int main()
{

    cout << "----------Actividad 1.4.-----------\n";

    cout << "N= ";
    cin >> N;

    cout << "M= ";
    cin >> M;

    cout << "\nIngresa un valor del laberinto (0|1): " << endl;
    
    vector<int> vec(M);

    for (int i = 0; i < N; i++)
    {
        maze.push_back(vec);
        solRatInMaze.push_back(vec);
        for (int j = 0; j < M; j++)
        {
            cin >> maze[i][j];
            solRatInMaze[i][j] = 0;
          //print(maze);
        }
    }

    cout << "\nLaberinto:" << endl;
    print(maze);

  
    backTracking();
}